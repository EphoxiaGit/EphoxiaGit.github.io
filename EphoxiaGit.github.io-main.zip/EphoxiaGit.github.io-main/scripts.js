$(document).ready(function() {
    $.ajax({
        url: "/",
       
